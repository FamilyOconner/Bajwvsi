#!/bin/sh
~/ccminer/ccminer -c ~/ccminer/config.json
